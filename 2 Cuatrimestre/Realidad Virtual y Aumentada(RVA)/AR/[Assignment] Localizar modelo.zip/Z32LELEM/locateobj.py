import cv2
from rva import calculaKPsDesc, matchDesc, localizaObj, draw_contour

def main(model_path='OPENCV3_model.jpg', scene_path='opencv3_scene.png'):
    # Carga imágenes en escala de grises para el procesamiento y en color para visualización
    img_modelo = cv2.imread(model_path, cv2.IMREAD_GRAYSCALE)
    img_escena = cv2.imread(scene_path, cv2.IMREAD_GRAYSCALE)
    img_escena_color = cv2.imread(scene_path, cv2.IMREAD_COLOR)

    # Verifica si las imágenes fueron cargadas correctamente
    if img_modelo is None or img_escena is None or img_escena_color is None:
        print("Error: no se pudieron cargar las imágenes")
        return -1

    # Detecta keypoints y calcula descriptores
    keypoints_modelo, descriptores_modelo = calculaKPsDesc(img_modelo)
    keypoints_escena, descriptores_escena = calculaKPsDesc(img_escena)
    
    # Empareja los descriptores
    matches = matchDesc(descriptores_modelo, descriptores_escena)

    # Localiza el modelo en la escena y dibuja las esquinas
    esquinas, H = localizaObj(img_modelo, img_escena, keypoints_modelo, keypoints_escena, matches)
    img_escena_color = draw_contour(img_escena_color, esquinas, (0, 255, 0), 4)

    # Muestra la imagen resultante
    cv2.namedWindow('Detectado', cv2.WINDOW_NORMAL)
    cv2.imshow("Detectado", img_escena_color)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Guardar la escena con el objeto localizado si es necesario
    # cv2.imwrite('output.jpg', img_escena_color)

if __name__ == '__main__':
    main()
