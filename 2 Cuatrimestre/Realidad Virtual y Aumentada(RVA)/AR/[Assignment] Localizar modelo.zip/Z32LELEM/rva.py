import cv2
import numpy as np

def calculaKPsDesc(imagen):
    """Calcula los keypoints y los descriptores usando ORB."""
    # Configura ORB con un número específico de features
    orb = cv2.ORB_create(nfeatures=1000)
    # Detecta keypoints y calcula descriptores
    keypoints, descriptors = orb.detectAndCompute(imagen, None)
    return keypoints, descriptors

def matchDesc(descriptores1, descriptores2):
    """Encuentra coincidencias entre descriptores de dos imágenes."""
    # Utiliza BFMatcher con norma Hamming y crossCheck
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    # Realiza el emparejamiento de los descriptores
    matches = matcher.match(descriptores1, descriptores2)
    return matches

def localizaObj(img_modelo, img_escena, keypoints_modelo, keypoints_escena, matches):
    """Calcula y traza las esquinas del modelo en la escena."""
    # Extrae puntos de modelo y escena basados en matches
    puntos_modelo = np.float32([keypoints_modelo[m.queryIdx].pt for m in matches]).reshape(-1,1,2)
    puntos_escena = np.float32([keypoints_escena[m.trainIdx].pt for m in matches]).reshape(-1,1,2)
    
    # Calcula la homografía usando RANSAC
    H, mask = cv2.findHomography(puntos_modelo, puntos_escena, cv2.RANSAC)
    
    # Determina las dimensiones del modelo y calcula las esquinas transformadas
    h, w = img_modelo.shape[:2]
    esquinas = np.float32([[0, 0], [0, h-1], [w-1, h-1], [w-1, 0]]).reshape(-1,1,2)
    esquinas_transformadas = cv2.perspectiveTransform(esquinas, H)
    return esquinas_transformadas, H

def draw_contour(img, esquinas, color, grosor):
    """Dibuja un contorno en la imagen."""
    # Convierte esquinas a formato usable para dibujar
    puntos = esquinas.reshape(-1, 2)
    puntos = np.int32(puntos)
    # Dibuja líneas entre los puntos consecutivos
    for i, punto in enumerate(puntos):
        punto_siguiente = puntos[(i+1) % len(puntos)]
        cv2.line(img, tuple(punto), tuple(punto_siguiente), color, grosor)
    return img
