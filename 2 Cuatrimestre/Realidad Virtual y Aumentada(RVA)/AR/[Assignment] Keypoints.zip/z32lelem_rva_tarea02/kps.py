# kps.py
import cv2
from rva import calculaKPsDesc, matchDesc, dibujaMatches

def main():
    # Carga las imágenes
    imagen1 = cv2.imread('transformed_image.jpg', cv2.IMREAD_GRAYSCALE)  # Asegúrate de que el camino a la imagen sea correcto
    imagen2 = cv2.imread('opencv3_scene.png', cv2.IMREAD_GRAYSCALE)

    # Calcula los keypoints y descriptores
    keypoints1, descriptores1 = calculaKPsDesc(imagen1)
    keypoints2, descriptores2 = calculaKPsDesc(imagen2)

    # Empareja los descriptores
    matches = matchDesc(descriptores1, descriptores2)

    # Dibuja los emparejamientos
    imagen_resultante = dibujaMatches(imagen1, keypoints1, imagen2, keypoints2, matches)

    # Muestra la imagen resultante
    
    cv2.namedWindow('Emparejamientos', cv2.WINDOW_NORMAL)
    cv2.imshow('Emparejamientos', imagen_resultante)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()

