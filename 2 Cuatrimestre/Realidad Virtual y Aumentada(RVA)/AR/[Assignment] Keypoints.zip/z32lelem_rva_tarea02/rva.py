# rva.py
import cv2
import numpy as np

def calculaKPsDesc(imagen):
    """Calcula los keypoints y descriptores de una imagen usando ORB."""
    orb = cv2.ORB_create()  # Crea un detector ORB
    keypoints, descriptors = orb.detectAndCompute(imagen, None)  # Detecta keypoints y calcula descriptores
    return keypoints, descriptors

def matchDesc(descriptores1, descriptores2):
    """Empareja los descriptores entre dos conjuntos de descriptores."""
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)  # Crea un objeto BFMatcher
    matches = matcher.match(descriptores1, descriptores2)  # Realiza el emparejamiento
    matches = sorted(matches, key=lambda x: x.distance)  # Ordena los matches por distancia
    return matches

def dibujaMatches(imagen1, keypoints1, imagen2, keypoints2, matches):
    """Dibuja los emparejamientos entre dos imágenes."""
    result_image = cv2.drawMatches(imagen1, keypoints1, imagen2, keypoints2, matches[:10], None, flags=2)  # Dibuja los primeros 10 matches
    return result_image
