import cv2
import argparse
import numpy as np
from rva_ import rva_calculaKPsDesc, rva_matchDesc, rva_localizaObj, rva_dibujaPatch, rva_draw_contour

def main(model_path, video_path, patch_path=None, video2_path=None, window_x=100, window_y=100):
    """
    Main function for video processing and augmented reality overlay.
    """
    # Load the model image
    img_model = cv2.imread(model_path, cv2.IMREAD_COLOR)
    if img_model is None:
        print(f"Error: Could not load model image: {model_path}")
        return

    # Resize the model image for consistency
    img_model = cv2.resize(img_model, None, fx=0.5, fy=0.5)

    # Load the patch if provided
    img_patch, use_patch = None, False
    if patch_path:
        img_patch = cv2.imread(patch_path, cv2.IMREAD_COLOR)
        if img_patch is not None:
            img_patch = cv2.resize(img_patch, (img_model.shape[1], img_model.shape[0]))
            use_patch = True

    # Open the primary video
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Error: Could not open video: {video_path}")
        return

    # Handle the secondary video ou webcam si fourni
    use_video2 = bool(video2_path)
    cap2 = None
    if use_video2:
        try:
            video2_index = int(video2_path)
            cap2 = cv2.VideoCapture(video2_index)
        except ValueError:
            cap2 = cv2.VideoCapture(video2_path)

        if not cap2.isOpened():
            print(f"Error: Could not load video or webcam: {video2_path}")
            return

    # Initialize keypoint detectors and descriptors for the model
    keypoints_model, descriptors_model = rva_calculaKPsDesc(img_model)

    # Video Writer initialization (for recording)
    record = False
    video_writer = None

    # Frame counter for screenshots
    frame_counter = 0

    # Create the window and move it to the specified position
    cv2.namedWindow("AugmentedReality", cv2.WINDOW_NORMAL)
    cv2.moveWindow("AugmentedReality", window_x, window_y)

    # Start processing frames from the main video
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # Resize the frame to half for faster processing
        frame = cv2.resize(frame, None, fx=0.5, fy=0.5)

        # Compute keypoints and descriptors for the current frame
        keypoints_scene, descriptors_scene = rva_calculaKPsDesc(frame)

        # Match descriptors between the model and the scene
        matches = rva_matchDesc(descriptors_model, descriptors_scene)

        # Initialize homography and locate object
        homography, pts_obj_in_scene = rva_localizaObj(img_model, frame, keypoints_model, keypoints_scene, matches)

        # If using secondary video, read a frame and resize to match the patch size
        if use_video2 and homography is not None:
            ret2, frame2 = cap2.read()
            if ret2:
                frame2 = cv2.resize(frame2, (img_model.shape[1], img_model.shape[0]))
                frame = rva_dibujaPatch(frame, frame2, homography)

        # Draw the patch on the scene if applicable
        if use_patch and homography is not None:
            frame = rva_dibujaPatch(frame, img_patch, homography)

        # Draw the bounding-box around the detected model object
        rva_draw_contour(frame, pts_obj_in_scene, (0, 255, 0), 4)

        # Start/stop video recording
        if record and video_writer is not None:
            video_writer.write(frame)

        # Display the augmented scene
        cv2.imshow("AugmentedReality", frame)

        # Check for pressed keys to take action
        key = cv2.waitKey(1)
        if key == 27:  # ESC key to stop the loop
            break
        elif key == ord('s'):  # "S" key to take a screenshot
            frame_counter += 1
            screenshot_path = f"screenshot_{frame_counter}.png"
            cv2.imwrite(screenshot_path, frame)
            print(f"Screenshot saved: {screenshot_path}")
        elif key == ord('r'):  # "R" key to start/stop video recording
            if not record:
                video_writer = cv2.VideoWriter("recorded_video.avi", cv2.VideoWriter_fourcc(*"XVID"), 20.0, (frame.shape[1], frame.shape[0]))
                record = True
                print("Recording started.")
            else:
                video_writer.release()
                video_writer = None
                record = False
                print("Recording stopped.")

    # Cleanup
    cap.release()
    if cap2:
        cap2.release()
    if video_writer:
        video_writer.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Augmented Reality Over Video")
    parser.add_argument("model", help="Path to image model.")
    parser.add_argument("video", help="Path to video scene.")
    parser.add_argument("--patch", help="Path to image patch.", default=None)
    parser.add_argument("--video2", help="Path to a second video ou webcam index.", default=None)
    parser.add_argument("--window_x", type=int, help="Horizontal position of the window.", default=100)
    parser.add_argument("--window_y", type=int, help="Vertical position of the window.", default=100)
    args = parser.parse_args()

    main(args.model, args.video, args.patch, args.video2, args.window_x, args.window_y)
