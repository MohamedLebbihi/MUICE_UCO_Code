import cv2
import numpy as np

# TASK 1

def rva_compute_homography(points_image1, points_image2):
    """
    Calculate the homography matrix using findHomography method.
    """
    return cv2.findHomography(np.array(points_image1), np.array(points_image2), cv2.RANSAC)[0]


def rva_draw_contour(image, points, color, thickness):
    """
    Draw the polygonal contour on the image.
    """
    int_points = [tuple(map(int, pt)) for pt in points]
    cv2.polylines(image, [np.array(int_points)], True, color, thickness)





# TASK 2

def rva_calculaKPsDesc(img):
    """
    Detect keypoints and compute descriptors using AKAZE.
    """
    akaze = cv2.AKAZE_create()
    keypoints, descriptors = akaze.detectAndCompute(img, None)
    return keypoints, descriptors


def rva_matchDesc(descriptors1, descriptors2, ratio_test=0.75):
    """
    Use a brute force matcher with the Hamming distance to match descriptors
    and apply Lowe's ratio test.
    """
    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
    knn_matches = matcher.knnMatch(descriptors1, descriptors2, k=2)

    # Apply ratio test to filter good matches
    matches = [m for m, n in knn_matches if m.distance < ratio_test * n.distance]

    return matches


def rva_dibujaMatches(img1, img2, keypoints1, keypoints2, matches):
    """
    Draw matches between two sets of keypoints.
    """
    return cv2.drawMatches(img1, keypoints1, img2, keypoints2, matches, None)


# TASK 3

def rva_localizaObj(img1, img2, keypoints1, keypoints2, matches, min_inliers=10):
    """
    Locate the object using matched keypoints between two images.
    """
    pts_img1 = np.float32([keypoints1[match.queryIdx].pt for match in matches])
    pts_img2 = np.float32([keypoints2[match.trainIdx].pt for match in matches])
    homography, mask = cv2.findHomography(pts_img1, pts_img2, cv2.RANSAC)

    # Check if homography meets minimum inlier requirement
    inliers = mask.sum()
    if inliers < min_inliers:
        return None, []

    # Transform the corners of img1 to img2 coordinate system
    corners_img1 = np.float32([[0, 0], [img1.shape[1], 0], [img1.shape[1], img1.shape[0]], [0, img1.shape[0]]])
    pts_im2 = cv2.perspectiveTransform(corners_img1[None, :, :], homography)[0]
    return homography, pts_im2


# TASK 4

def rva_dibujaPatch(scene, patch, H):
    """
    Warp the patch image using the homography matrix and overlay on the scene.
    """
    warped_patch = cv2.warpPerspective(patch, H, (scene.shape[1], scene.shape[0]))
    mask = cv2.cvtColor(warped_patch, cv2.COLOR_BGR2GRAY)
    _, mask = cv2.threshold(mask, 1, 255, cv2.THRESH_BINARY)
    output = scene.copy()
    cv2.copyTo(warped_patch, mask, output)
    return output
