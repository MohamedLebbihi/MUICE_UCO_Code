import cv2
import numpy as np

def rva_compute_homography(points1, points2):
    """Calcule et retourne la matrice d'homographie entre deux ensembles de points."""
    H, status = cv2.findHomography(np.array(points1), np.array(points2), cv2.RANSAC)
    return H

def rva_draw_contour(image, corners, color, thickness):
    """Dessine un contour (polygone) basé sur une liste de points."""
    num_points = len(corners)
    for i in range(num_points):
        cv2.line(image, corners[i], corners[(i + 1) % num_points], color, thickness)
    return image

def rva_deform_image(image, output_size, H):
    """Applique une transformation de perspective à l'image en utilisant la matrice d'homographie H."""
    warped_image = cv2.warpPerspective(image, H, output_size)
    return warped_image
