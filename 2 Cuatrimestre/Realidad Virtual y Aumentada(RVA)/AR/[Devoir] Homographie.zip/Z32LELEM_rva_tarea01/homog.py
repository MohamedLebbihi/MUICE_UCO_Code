# Importación de las bibliotecas necesarias
import cv2
from rva import rva_compute_homography, rva_draw_contour, rva_deform_image

# Esta función se llama cada vez que ocurre un evento de clic de ratón
def click_event(event, x, y, flags, params):
    global points, img  # Utilizamos variables globales para almacenar los puntos y la imagen
    # Si se presiona el botón izquierdo del ratón...
    if event == cv2.EVENT_LBUTTONDOWN:
        # Si hemos seleccionado menos de 4 puntos...
        if len(points) < 4:
            # Dibujamos un círculo rojo en la posición donde el usuario hizo clic en la imagen
            cv2.circle(img, (x, y), 5, (0, 0, 255), -1)  # Rojo
            # Añadimos el punto donde el usuario hizo clic a la lista de puntos
            points.append((x, y))
        # Si ya hemos seleccionado 4 puntos...
        if len(points) == 4:
            # Dibujamos un contorno verde conectando los puntos seleccionados, formando un polígono
            img = rva_draw_contour(img, points + [points[0]], (0, 255, 0), 2)  # Verde
            # Actualizamos la ventana de imagen para mostrar el contorno
            cv2.imshow('image', img)

# Función principal que se ejecutará cuando se inicie el script
def main():
    global img, points
    # Inicializamos la lista de puntos
    points = []
    # Cargamos la imagen desde el archivo especificado
    img = cv2.imread('OPENCV3_scene.png')  # Sustituye esto por la ruta a tu imagen

    # Creamos una ventana para la imagen y la mostramos
    cv2.namedWindow('image', cv2.WINDOW_NORMAL)
    cv2.imshow('image', img)
    # Asociamos la función click_event con la ventana de imagen para manejar los clics de ratón
    cv2.setMouseCallback('image', click_event)
    # Esperamos a que el usuario presione una tecla
    cv2.waitKey(0)
    # Cerramos todas las ventanas de OpenCV
    cv2.destroyAllWindows()

    # Comprobamos si se han seleccionado 4 puntos
    if len(points) != 4:
        # Si no es así, mostramos un mensaje
        print("No se han seleccionado cuatro puntos.")
        return

    # Definimos los puntos de destino para formar un rectángulo
    width, height = 300, 400
    dst_points = [(0, 0), (width-1, 0), (width-1, height-1), (0, height-1)]
    
    # Calculamos la matriz de homografía a partir de los puntos seleccionados
    H = rva_compute_homography(points, dst_points)
    # Definimos el tamaño de salida para la imagen transformada
    output_size = (width, height)
    # Aplicamos la transformación de perspectiva a la imagen utilizando la matriz de homografía
    transformed_img = rva_deform_image(img, output_size, H)

    # Mostramos la imagen transformada y la guardamos en el disco
    cv2.imshow('Imagen Transformada', transformed_img)
    cv2.imwrite('transformed_image.jpg', transformed_img)
    # Esperamos a que el usuario presione una tecla
    cv2.waitKey(0)
    # Cerramos todas las ventanas de OpenCV
    cv2.destroyAllWindows()

# Esta línea verifica si el script se ejecuta como el programa principal
if __name__ == '__main__':
    main()  # y si es así, ejecuta la función main()
