import network
import time
from machine import Pin
from umqtt.simple import MQTTClient

# Configuración Wi-Fi
SSID = "Wokwi-GUEST"  # Nombre de la red Wi-Fi
PASSWORD = ""  # Contraseña Wi-Fi (aquí vacía)

# Configuración MQTT
MQTT_BROKER = "broker.hivemq.com"  # Dirección del broker MQTT
MQTT_CLIENT_ID = "ESP32_Subscriber"  # Identificador del cliente MQTT para este sistema
MQTT_TOPIC = "wokwi/temperature"  # Tema (topic) al que el ESP32 se suscribe

# Inicializar el LED en GPIO15
led = Pin(15, Pin.OUT)  # Configurar el pin GPIO15 como salida para el LED

# Función para conectarse a Wi-Fi
def connect_wifi():
    print("Conectando a Wi-Fi...")
    wifi = network.WLAN(network.STA_IF)  # Configuración del ESP32 en modo estación
    wifi.active(True)  # Activación de la interfaz Wi-Fi
    wifi.connect(SSID, PASSWORD)  # Conexión a la red Wi-Fi
    
    while not wifi.isconnected():  # Bucle hasta que la conexión esté establecida
        print("Intentando conectar...")
        time.sleep(1)
    
    print("¡Conectado a Wi-Fi!")
    print("Dirección IP:", wifi.ifconfig()[0])  # Mostrar la dirección IP obtenida

# Función de callback para manejar los mensajes MQTT recibidos
def mqtt_callback(topic, msg):
    print("Mensaje recibido: {} en el tema {}".format(msg.decode(), topic.decode()))  # Mostrar el mensaje recibido
    
    try:
        # Convertir el mensaje en float
        temperature = float(msg.decode())  # Conversión del mensaje en número (temperatura)
        
        # Encender el LED si la temperatura supera los 25°C
        if temperature > 25:
            led.on()  # Encender el LED
            print("LED ON - Temperatura elevada")
        else:
            led.off()  # Apagar el LED
            print("LED OFF - Temperatura normal")
            
    except ValueError:
        print("Error: No se pudo convertir el mensaje en número.")  # Manejar el error de conversión

# Función para conectarse al broker MQTT y suscribirse al tema
def connect_mqtt():
    print("Conectando al broker MQTT...")
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER)  # Crear el cliente MQTT
    client.set_callback(mqtt_callback)  # Establecer la función de callback para los mensajes recibidos
    client.connect()  # Conexión al broker MQTT
    client.subscribe(MQTT_TOPIC)  # Suscribirse al tema especificado
    print("Suscrito al tema {}".format(MQTT_TOPIC))
    return client  # Devuelve el objeto cliente MQTT

# Función principal
def main():
    connect_wifi()  # Conectarse a Wi-Fi
    client = connect_mqtt()  # Conectarse al broker MQTT y suscribirse al tema

    while True:
        client.check_msg()  # Verificar los mensajes MQTT recibidos
        time.sleep(1)  # Pausa de un segundo entre las verificaciones

if __name__ == "__main__":
    main()  # Ejecutar la función principal si este script se ejecuta directamente
