import network
import time
from machine import Pin
import onewire, ds18x20
from umqtt.simple import MQTTClient

# Configuración Wi-Fi
SSID = "Wokwi-GUEST"  # Nombre de la red Wi-Fi a la que se debe conectar el ESP32
PASSWORD = ""  # Contraseña Wi-Fi (aquí vacía para la red Wokwi-GUEST)

# Configuración MQTT
MQTT_BROKER = "broker.hivemq.com"  # Dirección del broker MQTT
MQTT_CLIENT_ID = "ESP32_DS18B20"  # Identificador único para el cliente MQTT
MQTT_TOPIC = "wokwi/temperature"  # Tema (topic) en el que se publicarán los datos

# Inicializar el bus OneWire en el pin GPIO4
ow = onewire.OneWire(Pin(4))  # Configuración del bus OneWire en GPIO4 para los sensores DS18B20
ds_sensor = ds18x20.DS18X20(ow)  # Creación del objeto sensor DS18B20

# Función para conectarse a Wi-Fi
def connect_wifi():
    print("Conectando a Wi-Fi...")
    wifi = network.WLAN(network.STA_IF)  # Configuración del ESP32 en modo estación
    wifi.active(True)  # Activación de la interfaz Wi-Fi
    wifi.connect(SSID, PASSWORD)  # Conexión a la red Wi-Fi
    
    while not wifi.isconnected():  # Esperar hasta que la conexión sea exitosa
        print("Intentando conectar...")
        time.sleep(1)
    
    print("¡Conectado a Wi-Fi!")
    print("Dirección IP:", wifi.ifconfig()[0])  # Mostrar la dirección IP obtenida

# Función para conectarse al broker MQTT
def connect_mqtt():
    print("Conectando al broker MQTT...")
    client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER)  # Creación del objeto cliente MQTT
    client.connect()  # Conexión al broker MQTT
    print("¡Conectado al broker MQTT!")
    return client  # Devuelve el objeto cliente MQTT

# Función principal
def main():
    connect_wifi()  # Conectarse a Wi-Fi
    client = connect_mqtt()  # Conectarse al broker MQTT

    # Escanear los dispositivos OneWire (aquí, el DS18B20)
    roms = ds_sensor.scan()  # Buscar sensores DS18B20 en el bus OneWire
    if not roms:
        print("¡No se encontró ningún sensor DS18B20!")
        return
    
    print("Sensores encontrados:", roms)

    while True:
        try:
            ds_sensor.convert_temp()  # Iniciar la conversión de temperatura
            time.sleep_ms(750)  # Esperar 750 ms para que termine la conversión

            for rom in roms:
                temp = ds_sensor.read_temp(rom)  # Leer la temperatura del sensor

                if temp is not None:
                    print("Temperatura: {}°C".format(temp))
                    
                    # Publicar la temperatura en MQTT
                    client.publish(MQTT_TOPIC, str(temp))  # Enviar la temperatura al broker MQTT
                    print(f"Temperatura publicada en MQTT: {temp}°C")
                else:
                    print("Error al leer la temperatura.")
            
        except OSError as e:
            print("Error al leer el sensor.")
        
        time.sleep(2)  # Esperar 2 segundos antes de la siguiente medición

if __name__ == "__main__":
    main()  # Ejecutar la función principal si este script se ejecuta directamente
